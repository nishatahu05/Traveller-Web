<?php

$conn = mysqli_connect('localhost','root','','book_db') or die('connection failed');

?>